UncleMateo thanks you for downloading this mod! 
_____________
INSTALLATION:
First off, make sure you have the latest version of ModuleManager
Secondly, make sure that you have the mods 'BetterEarlyTree' and 'CommunityTechTree'
Merge the GameData folder provided with you Kerbal Space Program's GameData folder.
and... that's it!  

I hope you enjoy the adjustments to the early game, I think you'll find it adds both charm and challenge to the start of a career to have to select from a more limited list of parts.
Please also see my FelotaProject for TexturesUnlimited-based recoloring!